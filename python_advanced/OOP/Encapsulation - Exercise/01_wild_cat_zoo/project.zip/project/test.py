print("You have 3 workers\n"
      "----- 1 Keepers:\n"
      "Name: Tigy, Age: 40, Salary: 100\n"
      "----- 1 Caretakers:\n"
      "Name: Chi, Age: 24, Salary: 100\n----- 1 Vets:\nName: Leo, Age: 35, Salary: 100")